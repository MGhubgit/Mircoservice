package com.orderService.java.dto;

import lombok.Data;

@Data
public class FoodItemResponseDTO {
	private Integer foodItemId;
	private String foodName;
	private float price;
	private String foodType;	

}
