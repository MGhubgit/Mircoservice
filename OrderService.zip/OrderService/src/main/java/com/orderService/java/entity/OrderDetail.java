package com.orderService.java.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import lombok.Data;

@Data
@Entity
public class OrderDetail {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer orderDetailId;
	private int quantity;
	private float totalPrice;
	private LocalDateTime date;
	private long oderNumber;
	private Integer foodItemId;
	private Integer userId;
	
	@ManyToOne
	@JoinColumn(name="orderId")
	private Orders orders;

	
}
