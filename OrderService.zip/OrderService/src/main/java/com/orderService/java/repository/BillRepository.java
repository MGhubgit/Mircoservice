package com.orderService.java.repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.orderService.java.dto.OrderDetailResponseDTO;
import com.orderService.java.dto.UserResponseDTO;
import com.orderService.java.entity.OrderDetail;
import com.orderService.java.entity.User;


@Repository
public interface BillRepository extends CrudRepository<OrderDetail,Integer> {

	//Collection<OrderDetailResponseDTO> findByUser(UserResponseDTO user);

//	List<OrderDetail> findByUserLike(Integer id);
//@Query
//	List<OrderDetail> findByUser(Integer userId1);

//List<OrderDetailResponseDTO> findByUserId(Integer userId1);

	List<OrderDetail> findByUserId(Integer userId1);
	//@Query
//	List<OrderDetail> findByUserid(@Param(value = "userId") Integer userId);
	//List<OrderDetail> findByUserId(Integer userId);

}
