package com.orderService.java.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.orderService.java.dto.OrderDetailRequestDTO;
import com.orderService.java.dto.OrderDetailResponseDTO;
import com.orderService.java.dto.OrdersRequestDTO;
import com.orderService.java.feign.AccountClient;
import com.orderService.java.service.OrderService;


@RestController
@Validated
public class OrderDetailController {

	@Autowired
	private OrderService service;


	//---------------Place Order------------------
	@PostMapping("/orders")
	public String placeOrder(@Valid @RequestBody OrdersRequestDTO orders) {
		
		String msg = service.placeOrder(orders);
		if (msg!=null) {
			
			return msg;
		}
		return "Error is placing Order";
	}

	//--------------Get Order History--------------
	@GetMapping("/ordersHistory/{userId}")
	public List<OrderDetailResponseDTO> getHistory(@PathVariable Integer userId) {
		return service.getHistory(userId);
	}
}
