package com.orderService.java.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.orderService.java.dto.FoodIdRequestDTO;
import com.orderService.java.dto.FoodItemResponseDTO;



@FeignClient(name="FOODSERVICE")
//@FeignClient(name="foodservice",url="http://localhost:9092")
public interface FoodClient {

	@PostMapping("/foodItems/foodItemId")
	public List<FoodItemResponseDTO> getFoodItemById( @RequestBody FoodIdRequestDTO dto);
}
