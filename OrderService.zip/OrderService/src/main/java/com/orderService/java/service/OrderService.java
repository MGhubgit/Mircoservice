package com.orderService.java.service;

import java.util.List;

import com.orderService.java.dto.OrderDetailResponseDTO;
import com.orderService.java.dto.OrdersRequestDTO;


public interface OrderService {



	String placeOrder(OrdersRequestDTO orders);

	List<OrderDetailResponseDTO> getHistory(Integer usersId);


}
