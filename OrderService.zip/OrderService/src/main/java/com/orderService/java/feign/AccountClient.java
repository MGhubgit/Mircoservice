package com.orderService.java.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.orderService.java.dto.OrderDetailRequestDTO;



@FeignClient("ACCOUNTSERVICE")
//@FeignClient(name="accountservice",url="http://localhost:9094")
public interface AccountClient {

	@PostMapping("/transaction")
	public String performTransaction(@RequestBody OrderDetailRequestDTO dto);
	
	@GetMapping("/Orders")
	public float placeOrder(@RequestParam Integer userId);
}
