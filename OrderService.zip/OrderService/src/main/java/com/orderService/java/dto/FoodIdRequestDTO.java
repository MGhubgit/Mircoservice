package com.orderService.java.dto;


import java.util.List;

import javax.validation.constraints.NotEmpty;
import lombok.Data;
@Data
public class FoodIdRequestDTO {

	@NotEmpty(message = "Food Id cannot be empty")
	private List<Integer> foodItemId;
	
	
}
