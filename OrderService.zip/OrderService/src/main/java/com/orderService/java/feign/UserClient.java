package com.orderService.java.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.orderService.java.dto.UserResponseDTO;



@FeignClient(name="USERSERVICE")
//@FeignClient(name="userservice",url="http://localhost:9091")
public interface UserClient {

	@GetMapping("/users/{userId}")
	public UserResponseDTO getUserById(@PathVariable Integer userId);
}
