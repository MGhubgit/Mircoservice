package com.orderService.java.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.exception.MenuNotFoundException;
import com.orderService.java.dto.FoodIdRequestDTO;
import com.orderService.java.dto.FoodItemResponseDTO;
import com.orderService.java.dto.OrderDetailRequestDTO;
import com.orderService.java.dto.OrderDetailResponseDTO;
import com.orderService.java.dto.OrdersRequestDTO;
import com.orderService.java.dto.UserResponseDTO;
import com.orderService.java.entity.OrderDetail;
import com.orderService.java.entity.Orders;
import com.orderService.java.feign.AccountClient;
import com.orderService.java.feign.FoodClient;
import com.orderService.java.feign.UserClient;
import com.orderService.java.repository.BillRepository;
import com.orderService.java.repository.OrdersRepository;

@Service
public class OderDetailServiceImpl implements OrderService {

	@Autowired
	private OrdersRepository ordersRepository;
	@Autowired
	private BillRepository billrepository;
	@Autowired
	FoodClient foodClient;
	@Autowired
	AccountClient accountClient;
	@Autowired
	UserClient UserClient;

	// -------------------Get Order History By userId Using Java8----------------------
	@Override
	public List<OrderDetailResponseDTO> getHistory(Integer usersId) {
		List<OrderDetailResponseDTO> detailList = new ArrayList<OrderDetailResponseDTO>();

		UserResponseDTO user = UserClient.getUserById(usersId);
		Integer userId1 = user.getUserId();
		billrepository.findByUserId(userId1).stream().forEach(list1 -> {
			OrderDetailResponseDTO orderdetail = new OrderDetailResponseDTO();
			BeanUtils.copyProperties(list1, orderdetail);
			detailList.add(orderdetail);
		});
		return detailList;
	}

	// -------------------Placing Order by giving FoodId and Quantity--------------------
	@Override
	public String placeOrder(OrdersRequestDTO orders) {
		Orders o1 = new Orders();
		BeanUtils.copyProperties(orders, o1);
		FoodIdRequestDTO dto = new FoodIdRequestDTO();
		dto.setFoodItemId(orders.getFoodItemId());

		List<FoodItemResponseDTO> foodlist = foodClient.getFoodItemById(dto);

		OrderDetail detail;

		OrderDetail OrderDetail = null;

		if (foodlist.isEmpty()) {
			throw new MenuNotFoundException("Item Not Found");
		} else {
			System.out.println("---------Saving Orders--------");
			Orders o = new Orders();
			o.setFoodItemId(orders.getFoodItemId());
			o.setQuantity(orders.getQuantity());
			Orders order = ordersRepository.save(o);
			System.out.println(order);
			if (order != null) {
				System.out.println("------Saving OrderDetails------");
				Random random = new Random();

				detail = new OrderDetail();
				// detail.getFoodItem().setFoodItemId(foodItemId);

				float totalprice = 0;
				for (int i = 0; i <= order.getFoodItemId().size() - 1; i++) {
					// fi.setFoodItemId(order.getFoodItemId().get(i));
					detail.setFoodItemId(foodlist.get(i).getFoodItemId());
					detail.setQuantity(order.getQuantity().get(i));
					totalprice += order.getQuantity().get(i) * (foodlist.get(i).getPrice());
					detail.setTotalPrice(totalprice);
					detail.setDate(LocalDateTime.now());
					detail.setOderNumber(random.nextInt(1000));
					detail.setOrders(order);
					detail.setUserId(orders.getUserId());
					// System.out.println(detail);*/
					OrderDetail = billrepository.save(detail);
				}
				OrderDetailRequestDTO odto = new OrderDetailRequestDTO();
				odto.setTotalPrice(OrderDetail.getTotalPrice());
				odto.setUserId(OrderDetail.getUserId());
				System.out.println(odto);

				String msg = accountClient.performTransaction(odto);
				System.out.println(msg);
				if (msg.equalsIgnoreCase("Transaction Succesfull")) {
					return "Order placed and bill is of " + OrderDetail.getTotalPrice();
				} else {
					return "No Sufficinet Balance";
				}
			}

		}
		return "Order Not Placed";
	}
}
