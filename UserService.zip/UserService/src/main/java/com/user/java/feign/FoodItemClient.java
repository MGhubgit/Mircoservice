package com.user.java.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.user.java.dto.FoodItemResponseDTO;
import com.user.java.entity.FoodItem;

@FeignClient("FOODSERVICE")
//@FeignClient(name = "foodservice", url = "http://localhost:9092")
public interface FoodItemClient {

	@GetMapping("/foodItems")
	public List<FoodItemResponseDTO> getFoodList();

	@GetMapping("/foodItems/foodname")
	public List<FoodItemResponseDTO> getItemByName(@RequestParam String foodName);
	
	@GetMapping("/foodItems/{pageNo}/{pageSize}")
	public List<FoodItem> getPaginated (@PathVariable int pageNo,@PathVariable int pageSize);
	
	@GetMapping("/foodItems/port")
	public ResponseEntity<Integer> getPort();
}
