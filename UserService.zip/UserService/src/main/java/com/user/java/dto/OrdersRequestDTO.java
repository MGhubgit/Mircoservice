package com.user.java.dto;


import java.util.List;

import javax.validation.constraints.NotEmpty;

import lombok.Data;
@Data
public class OrdersRequestDTO {

	private Integer userId;
	@NotEmpty(message = "Food Id cannot be empty")
	private List<Integer> foodItemId;
	@NotEmpty(message = "Enter Quantity")
	private List<Integer> quantity;
	
}
