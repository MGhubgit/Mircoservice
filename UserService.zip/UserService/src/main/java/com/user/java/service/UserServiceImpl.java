package com.user.java.service;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.java.dto.UserResponseDTO;
import com.user.java.entity.User;
import com.user.java.repository.UserRepository;


@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository repository;

	//----------------------User Authentication---------------------
	
	@Override
	public boolean authenticateUser(String username, String password) {
		Optional<User> user=repository.findByUsername(username);
		System.out.println("Authenticating User");
		User u=(User) user.get();
		System.out.println(u);
		if(u.getPassword().equalsIgnoreCase(password)) {
				return true;
		}
		return false;
	}

	@Override
	public UserResponseDTO getUserById(Integer userId) {
		Optional<User> u=repository.findById(userId);
		UserResponseDTO udto=new UserResponseDTO();
		
		udto.setUserId(u.get().getUserId());
		udto.setUsername(u.get().getUsername());
		udto.setPassword(u.get().getPassword());
		udto.setAddress(u.get().getAddress());
		udto.setEmailId(u.get().getEmailId());
		udto.setPhoneNo(u.get().getPhoneNo());
		
		return udto;
	}

}
