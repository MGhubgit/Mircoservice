package com.user.java.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.user.java.dto.FoodItemResponseDTO;
import com.user.java.dto.OrderDetailResponseDTO;
import com.user.java.dto.OrdersRequestDTO;
import com.user.java.dto.UserRequestDTO;
import com.user.java.dto.UserResponseDTO;
import com.user.java.entity.FoodItem;
import com.user.java.feign.FoodItemClient;
import com.user.java.feign.OrderClient;
import com.user.java.service.UserService;

@RestController
@Validated
public class UserController {
	@Autowired
	private UserService service;
	@Autowired
	FoodItemClient itemClient;
	@Autowired
	OrderClient orderClient;

	// -------------User Authentication--------------------------

	@PostMapping("/users")
	public ResponseEntity<String> authenticateUser(@Valid @RequestBody UserRequestDTO userDTO) {
		boolean result = service.authenticateUser(userDTO.getUsername(), userDTO.getPassword());
		if (result == true) {
			return new ResponseEntity<String>("Login Successfull",HttpStatus.ACCEPTED);
		} else
			return new ResponseEntity<String>("Enter correct Username and Password",HttpStatus.NOT_ACCEPTABLE);
	}

	@GetMapping("/users/{userId}")
	public UserResponseDTO getUserById(@PathVariable Integer userId) {
		return service.getUserById(userId);
	}
	
    //---------------------Getting food Menu through feign------------
	@GetMapping("/users/feign/foodItems")
	public List<FoodItemResponseDTO> getFoodList() {
		System.out.println("InUser");
		return itemClient.getFoodList();
	}

	//---------------------Getting food Item By Name through feign------------
	@GetMapping("/users/feign/foodItems/foodname")
	public List<FoodItemResponseDTO> getItemByName(@RequestParam String foodName) {
		System.out.println("In User Food Name");
		return itemClient.getItemByName(foodName);
	}
	@GetMapping("/users/foodItems/{pageNo}/{pageSize}")
	public List<FoodItem> getPaginated (@PathVariable int pageNo,@PathVariable int pageSize){
		return itemClient.getPaginated(pageNo, pageSize);
	}
	
	@GetMapping("/users/feign/foodItems/port")
	public ResponseEntity<Integer> getPort() {
		return itemClient.getPort();
	}

	//---------------------Place Order through feign------------
	@PostMapping("/users/feign/orders")
	public String placeOrder(@Valid @RequestBody OrdersRequestDTO orders) {
		return orderClient.placeOrder(orders);
	}

	//--------------------- Order History through feign------------
	@GetMapping("/users/feign/ordersHistory/{userId}")
	public List<OrderDetailResponseDTO> getHistory(@PathVariable Integer userId) {
		return orderClient.getHistory(userId);
	}

}
