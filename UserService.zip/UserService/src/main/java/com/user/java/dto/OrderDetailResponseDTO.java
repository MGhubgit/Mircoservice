package com.user.java.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class OrderDetailResponseDTO {

	private Integer orderDetailId;
	private int quantity;
	private float totalPrice;
	private LocalDateTime date;
	private long oderNumber;
	
	
	

}
