package com.user.java.feign;

import java.util.List;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.user.java.dto.OrderDetailResponseDTO;
import com.user.java.dto.OrdersRequestDTO;

@FeignClient("ORDERSERVICE")
//@FeignClient(name = "orderservice", url = "http://localhost:9093")
public interface OrderClient {

	@PostMapping("/orders")
	public String placeOrder(@Valid @RequestBody OrdersRequestDTO orders);
	
	@GetMapping("/ordersHistory/{userId}")
	public List<OrderDetailResponseDTO> getHistory(@PathVariable Integer userId);
	
}
