package com.user.java.dto;

import lombok.Data;

@Data
public class UserResponseDTO {
	private Integer userId;
	private String username;
	private String password;
	private String address;
	private String phoneNo;
	private String emailId;

	
	
}
