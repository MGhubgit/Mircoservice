package com.user.java.service;

import com.user.java.dto.UserResponseDTO;

public interface UserService {

	public boolean authenticateUser(String username, String password);

	public UserResponseDTO getUserById(Integer userId);

}
