package com.food.java.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Value;
import com.food.java.dto.FoodIdRequestDTO;
import com.food.java.dto.FoodItemResponseDTO;
import com.food.java.entity.FoodItem;
import com.food.java.service.FoodItemService;
import com.java.exception.MenuNotFoundException;



@RestController
@Validated
public class FoodItemController {

	@Autowired
	private FoodItemService service;
	@Value("${server.port}")
	int port;

	//-------------Get Menu List------------------
	
	@GetMapping("/foodItems")
	public List<FoodItemResponseDTO> getFoodList() {
		System.out.println("In Food");
		List<FoodItemResponseDTO> list = service.getFoodList();
		System.out.println(list);
		if (list.isEmpty()) {
			throw new MenuNotFoundException("Menu Not Found");
		} else
			return list;
	}
	
	@GetMapping("/foodItems/{pageNo}/{pageSize}")
	public List<FoodItem> getPaginated (@PathVariable int pageNo,@PathVariable int pageSize){
	return service.findPaginated(pageNo, pageSize);
	}
	
    //---------------Find Food Item by Name----------
	
	@GetMapping("/foodItems/foodname")
	public List<FoodItemResponseDTO> getItemByName(@NotEmpty(message = "Food Id cannot be empty") @RequestParam String foodName) {
		List<FoodItemResponseDTO> fooditemlist = service.getFoodListByName(foodName);
		System.out.println("FoodLits"+fooditemlist);
		if (fooditemlist.isEmpty()) {
			throw new MenuNotFoundException("Menu Not Found");
		} else
			return fooditemlist;
	}
	//-----------------Get FoodList By Id-------------
	@PostMapping("/foodItems/foodItemId")
	public List<FoodItemResponseDTO> getFoodItemById(@RequestBody FoodIdRequestDTO dto){
		return service.getFoodById(dto);
	}
	//--------------Port Number---------------------
	@GetMapping("/foodItems/port")
	public ResponseEntity<Integer> getPort() {
		return new ResponseEntity<Integer>(port, HttpStatus.OK);
	}

}
