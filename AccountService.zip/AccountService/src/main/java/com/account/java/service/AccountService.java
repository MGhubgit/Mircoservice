package com.account.java.service;


import com.account.java.dto.OrderDetailRequestDTO;


public interface AccountService {

	public float getbalance(Integer userId);

	public String transaction(OrderDetailRequestDTO dto);

}
