package com.account.java.dto;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class OrderDetailRequestDTO {
	@NotNull(message ="Price cannot be null")
	private float totalPrice;
	@NotNull(message ="UserId Cannot be empty")
	private Integer userId;

	
}
